﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Test2Code;

namespace Test2Project
{
    /*
     * You should finish the Integration test
     */

    [TestClass]
    public class IntegrationTest2
    {
        //[TestMethod]
        //public void DemoMethod()
        //{
        //  
        //}
        [TestMethod]
        public void TestMethod()
        {

        }

    }
}
